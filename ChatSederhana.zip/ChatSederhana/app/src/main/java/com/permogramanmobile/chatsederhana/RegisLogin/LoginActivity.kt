package com.permogramanmobile.chatsederhana.RegisLogin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.permogramanmobile.chatsederhana.Message.LatestMessageActivity
import com.permogramanmobile.chatsederhana.R
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        text_back_regis.setOnClickListener() {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
            finish()
        }
        bt_login.setOnClickListener(){

            val email = Email_id_login.text.toString()
            val password = Pass_id_login.text.toString()
            FirebaseAuth.getInstance().signInWithEmailAndPassword(email,password)
                .addOnSuccessListener {
                    Log.d("Login","Login Sukses")
                    val intent = Intent(this, LatestMessageActivity::class.java)
                    startActivity(intent)
                }
                .addOnFailureListener{
                    email.isEmpty()
                    password.isEmpty()
                    Toast.makeText(this,"Email atau Password anda salah",Toast.LENGTH_SHORT).show()
                }

        }


    }
}
