package com.permogramanmobile.chatsederhana.Message

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.permogramanmobile.chatsederhana.ChatFromItem
import com.permogramanmobile.chatsederhana.ChatToItem
import com.permogramanmobile.chatsederhana.Module.ChatMessage
import com.permogramanmobile.chatsederhana.Module.User
import com.permogramanmobile.chatsederhana.R
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.GroupieViewHolder
import kotlinx.android.synthetic.main.activity_chat_log.*

class ChatLogActivity : AppCompatActivity() {
    companion object{
        val TAG = "Chat Log"
    }

    val adapter= GroupAdapter<GroupieViewHolder>()
    var toUser: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_log)

        recycleview_chat_log.adapter=adapter
        toUser = intent.getParcelableExtra<User>(NewMessageActivity.USER_KEY)

        supportActionBar?.title=toUser?.username
        listenForMessage()

        tombol_chat_log.setOnClickListener(){
            Log.d(TAG,"Pesan Terkirim")
            performSendMessage()
        }

    }


    private  fun listenForMessage(){
        val FromId = FirebaseAuth.getInstance().uid
        val ToId = toUser?.uid
        val ref =FirebaseDatabase.getInstance().getReference("/User-Message/$FromId/$ToId")

        ref.addChildEventListener(object: ChildEventListener {

            override fun onChildAdded(p0: DataSnapshot, p1: String?) {
                val chatMessage = p0.getValue(ChatMessage::class.java)

                if (chatMessage != null) {
                    Log.d(TAG, chatMessage.text)

                    if (chatMessage.FromId == FirebaseAuth.getInstance().uid) {
                        val currentUser = LatestMessageActivity.currentUser ?: return
                        adapter.add(ChatFromItem(chatMessage.text, currentUser))
                    } else {
                        adapter.add(ChatToItem(chatMessage.text, toUser!!))
                    }
                }

                recycleview_chat_log.scrollToPosition(adapter.itemCount - 1)

            }

            override fun onCancelled(p0: DatabaseError) {

            }

            override fun onChildChanged(p0: DataSnapshot, p1: String?) {

            }

            override fun onChildMoved(p0: DataSnapshot, p1: String?) {

            }

            override fun onChildRemoved(p0: DataSnapshot) {

            }

        })
    }


    fun performSendMessage(){

        val textpesan:String = text_chat_log.text.toString()

        val FromId: String? = FirebaseAuth.getInstance().uid
        val user:User =  intent.getParcelableExtra<User>(NewMessageActivity.USER_KEY)
        val ToId = user.uid


        if (FromId == null) return


        val reference = FirebaseDatabase.getInstance().getReference("/User-Message/$FromId/$ToId").push()

        val toReference = FirebaseDatabase.getInstance().getReference("/User-Message/$ToId/$FromId").push()

        val chatMessage = ChatMessage(reference.key!!, textpesan, FromId, ToId, System.currentTimeMillis()/1000)
//        reference.setValue(chatMessage)
//            .addOnSuccessListener {
//                Log.d(TAG,"Pesan tersimpan :${reference.key}")
//                text_chat_log.text.clear()
//
//            }
//        toReference.setValue(chatMessage)
//            .addOnSuccessListener {
//                Log.d(TAG,"Pesan tersimpan :${toReference.key}")
//                text_chat_log.text.clear()
//
//            }
        reference.setValue(chatMessage)
            .addOnSuccessListener {
                Log.d(TAG, "Saved our chat message: ${reference.key}")
                text_chat_log.text.clear()
                recycleview_chat_log.scrollToPosition(adapter.itemCount - 1)
            }

        toReference.setValue(chatMessage)

        val latestMessageRef = FirebaseDatabase.getInstance().getReference("/latest-messages/$FromId/$ToId")
        latestMessageRef.setValue(chatMessage)

        val latestMessageToRef = FirebaseDatabase.getInstance().getReference("/latest-messages/$ToId/$FromId")
        latestMessageToRef.setValue(chatMessage)
    }
}