package com.permogramanmobile.chatsederhana.Module

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class User(val uid:String,val profileImageUrl: String, val username:String, val password:String): Parcelable {
    constructor() : this("","","","")
}