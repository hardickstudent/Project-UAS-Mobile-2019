package com.permogramanmobile.chatsederhana.RegisLogin

import android.app.Activity
import android.content.ContentResolver
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.core.view.View
import com.google.firebase.storage.FirebaseStorage
import com.permogramanmobile.chatsederhana.Message.LatestMessageActivity
import com.permogramanmobile.chatsederhana.Module.User
import com.permogramanmobile.chatsederhana.R
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class RegisterActivity : AppCompatActivity() {

    companion object{
        val TAG = "Registeractivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button_register.setOnClickListener() {
            kliktombolregistration()
        }

        text_already_klik.setOnClickListener() {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        button_photo.setOnClickListener {
            Log.d(TAG, "Try to show photo selector")
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, 0)
        }
    }

    var selectedPhotoUri : Uri? =null

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 0 && resultCode == Activity.RESULT_OK && data != null) {

            Log.d(TAG, "Foto telah di pilih")

            selectedPhotoUri = data.data

            val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, selectedPhotoUri)

            select_photos.setImageBitmap(bitmap)

            button_photo.alpha = 0f
        }
    }
//

    private fun kliktombolregistration(){
        val emails = Email_id_text.text.toString()
        val passwords = Pass_id_text.text.toString()

        if (emails.isEmpty() || passwords.isEmpty()) {
            Toast.makeText(this, "Pastikan Data Telah di Isi Semua", Toast.LENGTH_SHORT).show()
            return
        }

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(emails,passwords)
            .addOnCompleteListener() {
                if(it.isSuccessful) return@addOnCompleteListener
                uploadphoto()
            }
            .addOnFailureListener(){
                Log.d(TAG,"Email  ${it.message} gagal ditambahkan ")
                Toast.makeText(this,"Gagal membuat akun  ${it.message}",Toast.LENGTH_SHORT).show()
            }
    }


    private fun uploadphoto(){
        if(selectedPhotoUri == null) return

        val filename = UUID.randomUUID().toString()
        val ref = FirebaseStorage.getInstance().getReference("photo/$filename")

        ref.putFile(selectedPhotoUri!!)
            .addOnSuccessListener {
                Log.d(TAG, "Successfully uploaded image: ${it.metadata?.path}")

                ref.downloadUrl.addOnSuccessListener {
                    Log.d(TAG, "File Location: $it")

                    SaveUser(it.toString())
                }
            }
            .addOnFailureListener {
                Log.d(TAG, "Failed to upload image to storage: ${it.message}")
            }
    }


    private fun SaveUser(profirleImageURL :String){

        val uid = FirebaseAuth.getInstance().uid?:""
        val ref = FirebaseDatabase.getInstance().getReference("Users/$uid")
        val user = User(uid,profirleImageURL,Username_id_text.text.toString(),Pass_id_text.text.toString())
        ref.setValue(user)
            .addOnSuccessListener {
                Log.d(TAG, "Data User Berhasil Disimpan")
                val intent = Intent(this, LatestMessageActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
            .addOnFailureListener(){
                Log.d(TAG, "Gagal menyimpan data : ${it.message}")
            }
    }
  }
