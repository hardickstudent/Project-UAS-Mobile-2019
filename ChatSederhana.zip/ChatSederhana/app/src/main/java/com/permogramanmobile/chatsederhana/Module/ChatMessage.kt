package com.permogramanmobile.chatsederhana.Module


class ChatMessage(val id:String, val text:String, val FromId:String, val ToId: String?, val timestamp: Long){
    constructor() : this("","","","",-1)
}

